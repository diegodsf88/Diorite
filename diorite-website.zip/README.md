# Diorite Website

Website sederhana bertema batuan diorit.

## Fitur
- Informasi dasar tentang diorit
- Fakta unik interaktif
- Desain dark theme

## Cara Menjalankan
Buka file index.html di browser.
