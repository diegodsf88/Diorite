function showFunFact() {
  const facts = [
    "Diorit sering digunakan dalam konstruksi bangunan.",
    "Batuan ini memiliki kekuatan yang tinggi.",
    "Diorit terbentuk jauh di bawah permukaan bumi.",
    "Digunakan oleh peradaban kuno untuk ukiran."
  ];

  const randomFact = facts[Math.floor(Math.random() * facts.length)];
  document.getElementById("fact").innerText = randomFact;
}
